if (('gato' === 'Gato') || (5 > 2)){
    console.log('Gato' && 'Cão');

}else {
    console.log('Falso');
}