/* var nome = "juquinha";
let sobrenome = "silva";
const idade = 30;

nome = "juca";
sobrenome = "silva pereira";
idade = 31; */

/*const idade = 31;
console.log(nome);*/

//var nome = "Maria",sobrenome = "silva", idade = 27;
//var nome = "Maria",
//    sobrenome = "silva",
//    idade = 27;

/*var nomeCompleto = "Maria terza";
nomeCompleto="jessica silva";
console.log(nomeCompleto);*/

/*var nomeCompleto;
console.log(nomeCompleto);
nomeCompleto = "Maria Silva";
console.log(nomeCompleto);
var idade = 27;*/

/*var teste = false;
console.log(teste);
var teste = true;*/
//imprime FALSE

var teste;
teste = false;
console.log(teste);
teste = true;
//imprime FALSE

//typeof = retorna dados das variaveis:
//console.log(typeof 'nome da variavel');