var nome = "Laura";
var sobrenome = 'Nagen';
var nomeCompleto = nome + ' ' + sobrenome;
console.log(nomeCompleto);
var idade = 20;
var comida = "Torresmo";
var um;
var dois;
var tres;