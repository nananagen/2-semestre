<view>
    <Text>alalalalal alallala</Text>
</view>