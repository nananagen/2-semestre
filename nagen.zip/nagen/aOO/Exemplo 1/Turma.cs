using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

class Turma
{
    private int periodo;
    private Aluno[] alunos = new Aluno[100];
    private int numeroAlunos = 0;

    public class Aluno
    {
        
    }
}